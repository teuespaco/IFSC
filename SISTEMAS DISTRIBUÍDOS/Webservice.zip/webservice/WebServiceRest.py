from flask import Flask, current_app, flash, jsonify, make_response, redirect, request, url_for, abort
from flask_httpauth import HTTPBasicAuth

app = Flask(__name__)
autenticacao = HTTPBasicAuth()

# Dados de exemplo para a API
livros = [
    {'id': 1, 'titulo': 'Linguagem de Programacao C', 'autor': 'Dennis Ritchie'},
    {'id': 2, 'titulo': 'Java como programar', 'autor': 'Deitel & Deitel'}
]

# Autenticação
@autenticacao.get_password
def obter_senha(usuario):
    if usuario == 'aluno':
        return 'senha123'
    return None

@autenticacao.error_handler
def nao_autorizado():
    return make_response(jsonify({'erro': 'Acesso Negado'}), 403)

# Tratamento de erros
@app.errorhandler(404)
def nao_encontrado(erro):
    return make_response(jsonify({'erro': 'Recurso Não Encontrado'}), 404)

# Rotas para a API
@app.route('/livros', methods=['GET'])
def obter_livros():
    return jsonify({'livros': livros})

@app.route('/livros/<int:id_livro>', methods=['GET'])
def obter_livro(id_livro):
    livro_encontrado = None
    for livro in livros:
        if livro['id'] == id_livro:
            livro_encontrado = livro
            break  

    if not livro_encontrado: 
        abort(404)
    return jsonify({'livro': livro_encontrado})


@app.route('/livros', methods=['POST'])
def criar_livro():
    if not request.json or 'titulo' not in request.json:
        abort(400)
    livro = {
        'id': livros[-1]['id'] + 1,
        'titulo': request.json['titulo'],
        'autor': request.json.get('autor', "")
    }
    livros.append(livro)
    return jsonify({'livro': livro}), 201

@app.route('/livros/<int:id_livro>', methods=['PUT'])
def atualizar_livro(id_livro):
    livro = None
    for l in livros:
        if l['id'] == id_livro:
            livro = l
            break

    if not livro:
        abort(404)
    if not request.json:
        abort(400)

    livro['titulo'] = request.json.get('titulo', livro['titulo'])
    livro['autor'] = request.json.get('autor', livro['autor'])
    return jsonify({'livro': livro})

@app.route('/livros/<int:id_livro>', methods=['DELETE'])
def excluir_livro(id_livro):
    livro = None
    for l in livros:
        if l['id'] == id_livro:
            livro = l
            break

    if not livro:
        abort(404)
    livros.remove(livro)
    return jsonify({'resultado': True})

@app.route('/livrosautenticado', methods=['GET'])
@autenticacao.login_required
def obter_livros_autenticado():
    return jsonify({'livros': livros})

if __name__ == "__main__":
    print('Servidor em execução...')
    app.run(debug=True)
