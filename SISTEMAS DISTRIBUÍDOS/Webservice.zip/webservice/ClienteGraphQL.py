import requests
import json

# Defina a URL do servidor GraphQL
graphql_url = 'http://localhost:5000/graphql'  # Atualize com o endereço do seu servidor GraphQL

# Função para fazer uma solicitação GraphQL
def graphql_request(query, variables=None):
    headers = {'Content-Type': 'application/json'}
    data = {'query': query, 'variables': variables}
    response = requests.post(graphql_url, json=data, headers=headers)

    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f'Erro na solicitação: {response.status_code}')

# Consulta GraphQL para obter a lista de livros
query_obter_livros = """
{
  livros {
    id
    titulo
    autor
  }
}
"""

# Mutação GraphQL para criar um novo livro
mutation_criar_livro = """
mutation {
  criarLivro(titulo: "Novo Livro", autor: "Autor Desconhecido") {
    livro {
      id
      titulo
      autor
    }
  }
}
"""

# Mutação GraphQL para atualizar um livro (substitua <ID_DO_LIVRO> pelo ID do livro desejado)
mutation_atualizar_livro = """
mutation {
  atualizarLivro(id: <ID_DO_LIVRO>, titulo: "Novo Título", autor: "Novo Autor") {
    livro {
      id
      titulo
      autor
    }
  }
}
"""

mutation_excluir_livro = """
mutation {
  excluirLivro(id: <ID_DO_LIVRO>) {
    sucesso
    mensagem
  }
}
"""
# Fazer solicitações GraphQL
try:
    # Obter a lista de livros
    lista_de_livros = graphql_request(query_obter_livros)
    print('Lista de Livros:')
    print(lista_de_livros)

    # Criar um novo livro
    novo_livro = graphql_request(mutation_criar_livro)
    print('Novo Livro Criado:')
    print(novo_livro)

    # Atualizar um livro existente (substitua <ID_DO_LIVRO> pelo ID do livro desejado)
    livro_id_a_atualizar = 1  # ID do livro a ser atualizado
    resultado_atualizacao = graphql_request(mutation_atualizar_livro.replace("<ID_DO_LIVRO>", str(livro_id_a_atualizar)))
    print('Resultado da Atualização:')
    print(resultado_atualizacao)
    
    livro_id_a_excluir = 1  # ID do livro a ser excluído
    resultado_exclusao = graphql_request(mutation_excluir_livro.replace("<ID_DO_LIVRO>", str(livro_id_a_excluir)))
    print('Resultado da Exclusão:')
    print(resultado_exclusao)    

except Exception as e:
    print(f'Erro: {e}')
