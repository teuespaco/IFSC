#pip install Flask Flask-GraphQL graphene
from flask import Flask, jsonify, request
from flask_graphql import GraphQLView
import graphene

app = Flask(__name__)

# Dados de exemplo para a API
livros = [
    {'id': 1, 'titulo': 'Linguagem de Programacao C', 'autor': 'Dennis Ritchie'},
    {'id': 2, 'titulo': 'Java como programar', 'autor': 'Deitel & Deitel'}
]

# Definindo o tipo de objeto GraphQL
class Livro(graphene.ObjectType):
    id = graphene.Int()
    titulo = graphene.String()
    autor = graphene.String()

# Definindo a consulta GraphQL
class Query(graphene.ObjectType):
    livros = graphene.List(Livro)
    livro = graphene.Field(Livro, id=graphene.Int())

    def resolve_livros(self, info):
        return livros

    def resolve_livro(self, info, id):
        for livro in livros:
            if livro['id'] == id:
                return livro
        return None

# Definindo a mutação GraphQL para criar e atualizar livros
class CriarLivro(graphene.Mutation):
    class Arguments:
        titulo = graphene.String(required=True)
        autor = graphene.String()

    livro = graphene.Field(Livro)

    def mutate(self, info, titulo, autor=None):
        novo_id = max([livro['id'] for livro in livros]) + 1
        novo_livro = {'id': novo_id, 'titulo': titulo, 'autor': autor}
        livros.append(novo_livro)
        return CriarLivro(livro=novo_livro)

class AtualizarLivro(graphene.Mutation):
    class Arguments:
        id = graphene.Int(required=True)
        titulo = graphene.String()
        autor = graphene.String()

    livro = graphene.Field(Livro)

    def mutate(self, info, id, titulo=None, autor=None):
        for livro in livros:
            if livro['id'] == id:
                if titulo is not None:
                    livro['titulo'] = titulo
                if autor is not None:
                    livro['autor'] = autor
                return AtualizarLivro(livro=livro)
        return None

class ExcluirLivro(graphene.Mutation):
    class Arguments:
        id = graphene.Int(required=True)

    sucesso = graphene.Boolean()
    mensagem = graphene.String()

    def mutate(self, info, id):
        livro_index = None
        for i, livro in enumerate(livros):
            if livro['id'] == id:
                livro_index = i
                break
        
        if livro_index is not None:
            livro_excluido = livros.pop(livro_index)
            return ExcluirLivro(sucesso=True, mensagem=f'O livro "{livro_excluido["titulo"]}" foi excluído com sucesso.')
        else:
            return ExcluirLivro(sucesso=False, mensagem='Livro não encontrado. Nenhum livro foi excluído.')


class Mutations(graphene.ObjectType):
    criar_livro = CriarLivro.Field()
    atualizar_livro = AtualizarLivro.Field()
    excluir_livro = ExcluirLivro.Field() 

schema = graphene.Schema(query=Query, mutation=Mutations)

# Rota GraphQL
app.add_url_rule('/graphql', view_func=GraphQLView.as_view('graphql', schema=schema, graphiql=True))

if __name__ == "__main__":
    print('Servidor GraphQL em execução...')
    app.run(debug=True)