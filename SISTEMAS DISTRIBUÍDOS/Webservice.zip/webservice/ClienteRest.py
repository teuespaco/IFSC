import requests
from requests.auth import HTTPBasicAuth

# Defina a URL base do servidor Flask
base_url = 'http://localhost:5000'  # Atualize com o endereço do seu servidor Flask

# Dados de autenticação
username = 'aluno'
password = 'senha123'

# Autenticação básica
auth = HTTPBasicAuth(username, password)

# Função para imprimir a resposta formatada
def print_response(response):
    print(f'Status Code: {response.status_code}')
    print('Resposta JSON:')
    try:
        data = response.json()
        print(data)
    except ValueError:
        print('A resposta não contém dados JSON.')

# Obter a lista de livros
response = requests.get(f'{base_url}/livros')
print('Obter a lista de livros:')
print_response(response)

# Obter informações de um livro específico (substitua <ID_DO_LIVRO> pelo ID do livro desejado)
livro_id = 1
response = requests.get(f'{base_url}/livros/{livro_id}')
print(f'Obter informações do livro com ID {livro_id}:')
print_response(response)

# Criar um novo livro
novo_livro = {'titulo': 'Python para Iniciantes', 'autor': 'John Smith'}
response = requests.post(f'{base_url}/livros', json=novo_livro, auth=auth)
print('Criar um novo livro:')
print_response(response)

# Atualizar um livro existente (substitua <ID_DO_LIVRO> pelo ID do livro desejado)
livro_id = 1
livro_atualizado = {'titulo': 'Novo Título', 'autor': 'Novo Autor'}
response = requests.put(f'{base_url}/livros/{livro_id}', json=livro_atualizado, auth=auth)
print(f'Atualizar informações do livro com ID {livro_id}:')
print_response(response)

# Excluir um livro existente (substitua <ID_DO_LIVRO> pelo ID do livro desejado)
livro_id = 2
response = requests.delete(f'{base_url}/livros/{livro_id}', auth=auth)
print(f'Excluir livro com ID {livro_id}:')
print_response(response)

# Obter a lista de livros autenticado
response = requests.get(f'{base_url}/livrosautenticado', auth=auth)
print('Obter a lista de livros autenticado:')
print_response(response)